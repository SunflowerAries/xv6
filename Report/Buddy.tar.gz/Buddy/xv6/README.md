# Lab1 Booting

Please update the local repository with

```git
git pull
```

Related project guides in the **guide** folder

