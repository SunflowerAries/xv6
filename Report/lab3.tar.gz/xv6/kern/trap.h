#ifndef KERN_TRAP_H
#define KERN_TRAP_H

void trap_init(void);

#endif /* !KERN_TRAP_H */