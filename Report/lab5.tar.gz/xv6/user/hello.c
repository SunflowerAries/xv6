// hello, world
#include <inc/lib.h>

void
umain(int argc, char **argv)
{
	cprintf("Hello, world.\n");
}
