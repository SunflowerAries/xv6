#include <inc/lib.h>

void
exit(void)
{
	sys_exit();
}